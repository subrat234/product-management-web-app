package com.example.productapp.controller;

    import com.example.productapp.entity.User;
    import com.example.productapp.repository.UserRepository;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.http.ResponseEntity;
    import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
    import org.springframework.web.bind.annotation.*;

    @RestController
    @RequestMapping("/api/auth")
    public class AuthController {

        @Autowired
        private UserRepository userRepository;

        private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        @PostMapping("/signup")
        public ResponseEntity<?> register(@RequestBody User user) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            return ResponseEntity.ok(userRepository.save(user));
        }
    }