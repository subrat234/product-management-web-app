import React from 'react';
    import { Routes, Route, Link } from 'react-router-dom';
    import Signup from './pages/Signup';
    import Login from './pages/Login';
    import ProductList from './pages/ProductList';

    function App() {
      return (
        <div className="App">
          <nav>
            <Link to="/signup">Signup</Link> | <Link to="/login">Login</Link> | <Link to="/products">Products</Link>
          </nav>
          <Routes>
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/products" element={<ProductList />} />
          </Routes>
        </div>
      );
    }

    export default App;